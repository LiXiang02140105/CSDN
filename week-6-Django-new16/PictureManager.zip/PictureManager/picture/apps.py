from django.apps import AppConfig


class PictureConfig(AppConfig):
    name = 'picture'
