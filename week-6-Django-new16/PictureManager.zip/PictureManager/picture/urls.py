from django.contrib import admin
#from django.urls import path
from django.conf.urls import include, url
from picture import views
#from . import views


urlpatterns = [
    #path('^admin/', admin.site.urls),
    url(r'^$',views.index, name = 'index'), # 默认进入的模块

    # 浏览图片信息
    url(r'^select/$',views.selectPics,name = 'selectpics'),# 无参数
    url(r'^select/pIndex=(?P<pIndex>[0-9]+)$',views.selectPics,name = 'selectpics'), # 有参数

    # 添加图片信息
    url(r'^add/$',views.addPics,name = 'addpics'), # 填写图片信息表单
    url(r'^insert/$',views.insertPics,name = 'insertpics'), # 获取图片表单, 插入到数据库

    # 编辑图片信息
    url(r'^edit/$',views.editPics,name = 'editpics'),
    url(r'^update/$',views.updatePics,name = 'updatepics'),

    # 删除图片信息
    url(r'^delete/pid=(?P<pid>[0-9]+)$',views.deletePics,name = 'deletepics'),
]