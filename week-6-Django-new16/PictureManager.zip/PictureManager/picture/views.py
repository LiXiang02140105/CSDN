from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
import os

from picture.models import Picture
# 导入 picture 模板对象
from django.core.paginator import Paginator
# 分页对象

from PIL import Image
# 绘图对象
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
def index(request):
    return render(request, 'index.html')

'''
1、浏览信息：获取数据库中所有的用户信息
    Picture.objects对象
'''
def selectPics(request,pIndex='1'):
    picob = Picture.objects # 数据库 manager对象
    picslist = picob.all()
    print(picslist)
    for pic in picslist:
        print("图片: ", pic.id, pic.name, pic.picture, pic.time)
    if picslist.count() == 0:
        # 判断查询结果集 中的数量
        context = {"info" : "系统中没有维护的图片!"}
        return render(request,'info.html', context)
    else:
        picspages = Paginator(picslist,5) # 5个/页
        pIndex = int(pIndex) # 当前页码
        pics = picspages.page(pIndex) # 当前页的 picture
        prange = picspages.page_range # 所有页码
        # 输出：当前页的内容，当前页，总页数，
        context = {
            "pics" : pics,
            "pIndex" : pIndex,
            "prange" : prange
        }
        print("context: ",context)
        return render(request,'picture/select.html', context)
'''
    1、获取 addPics 的 html页面 -> 用来获取 添加的内容
    2、-> insertPics 获取 -> 添加到数据库 + 写到 media 里
'''
def addPics(request):
    return render(request, "picture/add.html")

def insertPics(request):
    # 1、新建 Picture 对象
    pic = Picture()
    # 2、获取各自的 内容
    pic.name = request.POST['name']
    pic.picture = request.FILES.get('image',None)
    # FILE 具有:name,chunks
    if not pic.name or not pic.picture:
        context = {"info": "没有获取到上传文件信息!"}
    else:
        now = datetime.now()
        pic.time = now.strftime("%Y-%m-%d %H:%M:%S")
    # 3、使用chunks的方式，将图片分块绘制
        filename = str(now.strftime("%Y%m%d-%H%M%S")) + "." + pic.picture.name.split(".").pop()
        print("filename: ",filename)
        # 3.1 获取文件，保存到 static/picture 里
        
        # 3.2 绘制原图
        origin_pic = open("./static/picture/O_" + filename, "wb+")
        for chunk in pic.picture.chunks():
            origin_pic.write(chunk)
        origin_pic.close()
        # 3.3 绘制缩小图
        img = Image.open("./static/picture/O_" + filename)
        # 1. 缩放到75*75(缩放后的宽高比例不变):
        # 还有一个 resize() 方法
        img.thumbnail((50,50))
        # 2. 保存图片
        img.save("./static/picture/S_" + filename, None)   
        
        # 3.4 绘制放大图
        img = Image.open("./static/picture/O_" + filename)
        # 1. 缩放到75*75(缩放后的宽高比例不变):
        # 还有一个 resize() 方法
        img.thumbnail((100,100))
        # 2. 保存图片
        img.save("./static/picture/M_" + filename, None)   
# 4、保存并返回
        pic.picture = filename # 保存文件名到数据库里
        print("picInfo: ",pic.name,pic.time, pic.picture )
        pic.save() # 保存数据库对象
        context ={"info" : "保存图片信息成功!"}
        #except:
        #    context ={"info" : "保存图片信息失败!"}
    # 3、图片保存成功， 将图片信息保存至 数据库中
    return render(request, 'info.html', context)



def editPics(request):
    """得到当前的pid"""
    pid = int(request.GET['pid'])
    # 得到 picob, 并展示
    picob = Picture.objects.get(id = pid)
    if picob == None:
        context = {"info": "系统错误, 没有找到这条记录!"}
        return render(request, "info.html", context)
    else:
        context = {"picob": picob}
        return render(request, "picture\edit.html", context)
    



'''csrf的token
1、在form表单里一起{% csrf_token %}
2、在获取表单的函数前，加装饰器
'''   
@csrf_exempt
def updatePics(request):
    pid = int(request.POST["id"])
    # 1、得到原始的 信息
    origin = Picture.objects.get(id=pid)
    # 2、得到新的信息
    new_name = request.POST['name']
    new_pic = request.FILES.get('new', None)
    # 3、判断图片 和 名字有没有更新
    if not new_pic and new_name == origin.name :
        # 没有更新图片
        context = {"info": "图片信息没有更新!"}
        return render(request, "info.html", context)
    # 4、更新: 图片名、图片、时间
    new = origin
    now = datetime.now()
    new.time = now.strftime("%Y-%m-%d %H:%M:%S")
    new.name = new_name
    #try:
    print("new_pic:",new_pic)
    if new_pic:
        # 5、如果有新图片
        # 5.1 删除之前的照片
        os.remove("./static/picture/O_" + origin.picture.name )
        os.remove("./static/picture/M_" + origin.picture.name )
        os.remove("./static/picture/S_" + origin.picture.name )
        # 5.2 绘制新的图片
        filename = str(now.strftime("%Y%m%d-%H%M%S")) + "." + new_pic.name.split(".").pop()
        # 5.3 新建文件
        destination = open("./static/picture/O_" + filename, "wb+")
        # 5.4 分块写入
        for chunk in new_pic.chunks():
            destination.write(chunk)
        destination.close()

        # 5.5 绘制缩略图
        img = Image.open("./static/picture/O_" + filename)
        img.thumbnail((50,50))
        img.save("./static/picture/S_" + filename, None)
        # 5.6 绘制放大图
        img = Image.open("./static/picture/O_" + filename)
        img.thumbnail((100,100))
        img.save("./static/picture/M_" + filename, None)
        # 5.7 保存图片名、图片、时间
        new.picture = filename
            
        
        print("picInfo: ",new.name,new.time, new.picture )
        new.save() # 保存数据库对象
        context ={"info" : "更新图片信息 成功!"}
        return render(request, "info.html", context)
    #except:
        #context ={"info" : "更新图片信息 失败!"}
    new.save() # 保存数据库对象
    print("picInfo: ",new.name,new.time, new.picture )
    context ={"info" : "更新图片信息 成功!"}
    return render(request, "info.html", context)
        

def deletePics(request, pid):
    pid = int(pid)
    picob = Picture.objects.get(id=pid)
    try:
        # 删除图片文件
        os.remove("./static/picture/O_" + picob.picture.name)
        os.remove("./static/picture/M_" + picob.picture.name)
        os.remove("./static/picture/S_" + picob.picture.name)
        # 删除 图片数据库对象
        picob.delete()
        context = {"info":"删除id为 %d 的图片成功!" % (pid)}
    except:
        context = {"info":"删除id为 %d 的图片失败" % (pid)}
    return render(request, "info.html", context)