"""PictureManager URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
'''编写时长记录
2019.6.5 09:30-10:00 30min
2019.6.6 09:04-10:00 60min
2019.6.8 10:00-12:00 14:00-17:00 120+180=300
2019.6.10 09:00-10:00 60min
2019.6.11 08:50-09:40 50min
2019.6.12 08:40-09:50 70min
2019.6.13 08:50-10:00 70min 编辑&删除 
                            剩余跑通 & 改良页面显示(select上一页&add和edit上传新图片的显示)
2019.6.14 00:00-00:40 40min finished
'''
"""
a) Django的框架搭建
b) 相册信息添加功能（信息添加，图片上传和缩放）
c) 相册信息浏览（信息和图片的浏览，分页功能）
d) 相册信息编辑（信息编辑，可更换图片）
e) 相册信息删除（要求同时删除图片）
"""
from django.contrib import admin
#from django.urls import path
from django.conf.urls import include, url


urlpatterns = [
    #path('^admin/', admin.site.urls),
    url(r'^',include('picture.urls')), # 不输入任何模块，进入picture app
]
