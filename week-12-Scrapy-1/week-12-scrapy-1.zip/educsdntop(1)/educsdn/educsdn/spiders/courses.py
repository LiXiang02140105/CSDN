    # -*- coding: utf-8 -*-
import scrapy
from educsdn.items import CoursesItem

class CoursesSpider(scrapy.Spider):
    name = 'courses'
    allowed_domains = ['edu.csdn.net']
    start_urls = ['https://edu.csdn.net/courses/o280/p1']
    p=1
    def parse(self, response):
        # 解析并输出课程标题
        with open("csdn.html","w") as fp:
            fp.write(response.text)
        print(response.text)
        content = response.selector.css("div.course_html").extract()
        # 获取所有课程
        dlist = response.selector.css("div.course_item")
        # 遍历课程，并解析信息后封装到item容器中
        for dd in dlist:
            item = CoursesItem()
            item['title'] = dd.css("span.title::attr(title)").extract_first()
            item['url'] = dd.css("a::attr(href)").extract_first()
            item['pic'] = dd.css("dl.course_item_inner dd img::attr(src)").extract_first()
            item['teacher'] = dd.css("span.lecname::attr(title)").extract_first()
            item['time'] = dd.css("span.course_lessons::text").extract_first()
            item['price'] = str(dd.css("p.priceinfo i::text").extract_first()).strip().replace("￥","")
            print(item)
            yield item
        '''
        #获取前10页的课程信息 
        self.p += 1
        if self.p <= 10:
            next_url = 'https://edu.csdn.net/courses/o280/p'+str(self.p)
            url = response.urljoin(next_url) #构建绝对url地址（这里可省略）
            yield scrapy.Request(url=url,callback=self.parse)
        '''
