# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
from scrapy import Request
from scrapy.pipelines.images import ImagesPipeline
from scrapy.exceptions import DropItem

class EducsdnPipeline(object):
    def process_item(self, item, spider):
        #print(item)
        #print("="*70)
        return item

'''执行数据库的存储
'''
class MongoDBPipeline(object):
    '''
    def __init__(self,host,database,user,password,port):
        self.host = host
        self.database = database
        self.user =  user
        self.password = password
        self.port = port
        self.db=None
        self.cursor=None
    
    @classmethod
    def from_crawler(cls,crawler):
        return cls(
            host = crawler.settings.get("MYSQL_HOST"),
            database = crawler.settings.get("MYSQL_DATABASE"),
            user = crawler.settings.get("MYSQL_USER"),
            password = crawler.settings.get("MYSQL_PASS"),
            port = crawler.settings.get("MYSQL_PORT")
        )'''

    def open_spider(self,spider):
        self.client = pymongo.MongoClient("localhost",27017)
        self.db = self.client.scrapy
        self.collect = self.db.csdn
        self.id = self.collect.count() + 1# 得到id

    def process_item(self, item, spider):
        document = {
            "_id" : self.id,
            "title" :item["title"],
            "url" : item["url"],
            "pic" : item["pic"],
            "teacher" : item["teacher"] ,
            "time" : item["time"],
            "price": item["price"],
        }
        self.id += 1
        '''
        sql = "insert into courses(title,url,pic,teacher,time,price) values('%s','%s','%s','%s','%s','%s')"%(item['title'],item['url'],item['pic'],item['teacher'],str(item['time']),str(item['price']))
        print(item)
        self.cursor.execute(sql)
        self.db.commit()
        '''
        self.collect.insert_one(document).inserted_id
        return item
    
        '''
    def close_spider(self,spider):
        self.db.close()
        '''

class ImagePipeline(ImagesPipeline):
    '''自定义图片存储类'''

    def get_media_requests(self, item, info):
        '''通过抓取的item对象获取图片信息
        并创建Request请求对象添加调度队列
        等待调度执行下载
        '''
        
        print('get_media_request','!'*100)
        print(item['pic'])
        yield Request(item["pic"])

    def file_path(self, request, response=None, info=None):
     
        image_guid = request.url.split('/')[-1]
        print(image_guid,'='*10)
        return image_guid

    def item_completed(self, results, item, info):
        '''如果图片下载成功后
        [(
            True, 
            {
                'url': 'https://img-bss.csdn.net/201803191642534078.png', 
                'path': '201803191642534078.png', 
                'checksum': 'cc1368dbc122b6762f3e26ccef0dd105'
            }
         )]
        '''
        print(results[0][1])
        res=results[0][1]
        for result,value in res:
            if result:
                
                image_path = value["path"]
                if not image_path:
                    # 如果没有图片
                    raise DropItem("no image for this item")

                item["image_path"] = image_path
        return item
