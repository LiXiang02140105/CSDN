'''
直接运行文件
'''
from scrapy import cmdline
cmdline.execute(["scrapy","crawl","login"])