# -*- coding: utf-8 -*-
import scrapy


class LoginSpider(scrapy.Spider):
    name = 'login'
    allowed_domains = ['www.renren.com']
    start_urls = ['http://www.renren.com/SysHome.do']
    #def start_requests(self):
        #url = 'http://www.renren.com/SysHome.do'
    def parse(self, response):
        data = {
            'email' : "15173347364",
            'password': ''
            }
        # FormRequest 是Scrapy发送POST请求的方法
        yield scrapy.FormRequest.from_response(
            response,
            formdata = data,
            callback = self.after_login
        )
    def after_login(self,response):
        print(response.status)
        with open("renren.html","w",encoding="utf-8") as fp:
            fp.write(response.text)
