# -*- coding: utf-8 -*-
import scrapy
from sina.items import SinaItem

class SinaSpiderSpider(scrapy.Spider):
    name = 'sina_spider'
    allowed_domains = ['news.sina.com.cn']
    start_urls = ['http://news.sina.com.cn/guide/']

    def parse(self, response):
        sections = response.css("div.section")
        contents = [] # 页面上所有的内容
        for section in sections:
            titles = section.css("h2.tit01::text").extract()
            title = ".".join(titles) # 大模块标题
            subsections = section.css("div.clearfix") # 子模块
            subcontent = []
            for item in subsections:
                subtitle = item.xpath("./h3/a/text()").extract_first()
                subcontent_text = item.xpath("./ul[@class='list01']/li/a/text()").extract()
                subcontent_url = item.xpath("./ul[@class='list01']/li/a/@href").extract()
                # 把每一个内容按照 title + url，做成dict
                temps = []
                for i in range(0,len(subcontent_text)):
                    temp = { 
                        "title" : subcontent_text[i],
                        "url" : subcontent_url[i],
                    }
                    temps.append(temp)
                subsection = {
                    "subtitle" : subtitle,
                    "content" : temps,
                }
                subcontent.append(subsection)
            content = {
                "title" : title,
                "content" : subcontent,
            }
            item = SinaItem()
    
            contents.append(content)
        print(contents)

                #
