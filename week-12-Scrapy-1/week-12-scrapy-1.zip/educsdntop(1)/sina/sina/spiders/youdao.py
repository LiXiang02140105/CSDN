# -*- coding: utf-8 -*-
import scrapy,json


class YoudaoSpider(scrapy.Spider):
    name = 'youdao'
    allowed_domains = ['http://fanyi.youdao.com']
    #start_urls = ['http://http://fanyi.youdao.com/']

    def start_requests(self):
        url = "http://fanyi.youdao.com/translate?smartresult=dict&smartresult=rule"
        kw = input("请输入要翻译的单词")
        kw = {
            "i" :kw,
            "doctype" : "json"
        }
        yield scrapy.FormRequest(
            url = url,
            formdata=kw,
            callback=self.parse
        )

    def parse(self, response):
        re = json.loads(response.body)
        print(re["translateResult"][0][0]["tgt"])

