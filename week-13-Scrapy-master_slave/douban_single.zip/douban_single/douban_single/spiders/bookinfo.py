# -*- coding: utf-8 -*-
import scrapy
import redis
from scrapy_redis.spiders import RedisSpider
import pymysql, re
from douban_single.items import BookItem

class BookinfoSpider(scrapy.Spider):
    name = 'bookinfo'
    allowed_domains = ['book.douban.com']
    start_urls = ['https://book.douban.com/tag/?view=type&icn=index-sorttags-all']
    r_db = redis.Redis(host='localhost', port=6379, decode_responses=True)
    #m_db = pymysql.Connection(host='localhost',user='root', passwd='', db='scrapy',port=3306)
    #redis_key = 'douban:tag_urls'

    def parse(self, response):
        # 得到tag, 并请求tag
        tags = response.xpath("//td/a/@href").getall() # 得到文案
        for tag in tags:
            if '/tag/' in tag:
                if 'douban:tag_urls' not in self.r_db.keys():
                    self.r_db.lpush('douban:tag_urls', tag)
                    # tag = '/tag/外国文学'
                    tag_url = response.urljoin(tag) # 拼接新的url
                    yield scrapy.Request(url=tag_url,callback=self.parse_url)
    
    def parse_url(self, response):
        # 得到当前页的book_url
        print(response.text)
        book_urls = response.css('a.nbg::attr(href)').getall()
        print("页面url:", book_urls)
        for book_url in book_urls:
            if book_url:
                if 'douban:book_urls' not in self.r_db.keys():
                    self.r_db.lpush('douban:book_urls', book_url)
                book_url = response.urljoin(book_url) # 拼接新的url
                print("book_url: %s" % book_url)
                yield scrapy.Request(url=book_url,callback=self.parse_bookinfo)
                # break # 得到一本书break
        
        # 请求下一页数据
        
        next_url = response.css('span.next a::attr(href)').get()
        print('下一页:%s' % next_url)
        if next_url:
            next_url = response.urljoin(next_url)
            yield scrapy.Request(url=next_url, callback=self.parse_url)

    def parse_bookinfo(self, response):
        item = BookItem()
        item['book_id'] = re.match(r'.+/subject/(\d+?)/', response.url).group(1) # 图书编号
        item['book_pic'] = response.css("div#mainpic a.nbg::attr(href)").get() # 传递 封面url
        item['title'] = response.css("div#mainpic a.nbg::attr(title)").get() # 书名
        infos = list(map(lambda value: re.sub(r'[:|\s|\n]','',value),infos))
        infos = [i for i in infos if i != '']
        for index,key in enumerate(infos):
            if key == '作者':
                item['author'] =infos[index+1]
            elif key == '出版社':
                item['publisher'] =infos[index+1]
            elif key == '译者':
                item['translator'] =infos[index+1]
            elif key == '出版年':
                item['imprint'] =infos[index+1]
            elif key == '页数':
                item['pages'] =infos[index+1]
            elif key == '定价':
                item['price'] =infos[index+1]
            elif key == '装帧':
                item['binding'] =infos[index+1]
            elif key == '丛书':
                item['series'] =infos[index+1]
            elif key == 'ISBN':
                item['isbn'] =infos[index+1]
        item['score'] =response.xpath("//strong[contains(@class,'rating_num')]/text()").get().strip()
        item['number'] =response.xpath("//a[@class='rating_people']/span/text()").get()
        yield item

