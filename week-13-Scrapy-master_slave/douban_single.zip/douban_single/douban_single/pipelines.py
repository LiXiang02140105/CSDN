# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.pipelines.images import ImagesPipeline
from scrapy import Request
from scrapy.exceptions import DropItem
import pymysql,pymongo


class ImagePipeline(ImagesPipeline):
    def get_media_requests(self, item, info):
        '''通过抓取的item对象获取图片信息， 并创建Request请求对象，添加调度队列，等待调度执行下载'''
        yield Request(item['book_pic'])


    def file_path(self, request, response=None, info=None):
        # 定义下载图片存储的名称
        image_name = request.url.split("/")[-1]
        return image_name

    def item_completed(self, results, item, info):
        '''下载完成后，将没有成功下载的对象剔除'''
        image_path = [ x['path'] for ok,x in results if ok ]
        if not image_path :
            raise DropItem("Item contain no file")
        item["image_path"] = image_path
        yield item

class MysqlPipeline(object):
    def __init__(self, host, user, passwd, port, database, table):
        self.host = host
        self.user = user
        self.passwd = passwd
        self.port = port
        self.database = database
        self.table = table

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            host = crawler.setting.get("MYSQL_HOST"), 
            user = crawler.setting.get("MYSQL_USER"), 
            passwd = crawler.setting.get("MYSQL_PASS"), 
            port = crawler.setting.get("MYSQL_PORT"), 
            database = crawler.setting.get("MYSQL_DATABASE"),
            table = crawler.setting.get("DOUBAN_TABLE")
        )

    def open_spider(self, spider):
        self.db = pymysql.connect(self.host,self.user,self.password,self.database,charset='utf8',port=self.port)
        self.cursor = self.db.cursor()

    def process_item(self, item, spider):
        sql = "insert into %s(book_id,title,author,publisher,translator,imprint,pages,price,binding,series,isbn,score,number,image_path) \
            values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (str(item['book_id']), item["title"], item["author"],item["publisher"],item["translator"],item["imprint"],str(item["pages"]),str(item["price"]), item["binding"],item["series"],item["isbn"],item["score"],item["number"],item["image_path"])
        self.cursor.execute(sql)
        self.m_db.commit()
        return item

    def close_spider(self,spider):
        self.m_db.close()