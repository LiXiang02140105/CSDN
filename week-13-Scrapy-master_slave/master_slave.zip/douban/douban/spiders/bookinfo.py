# -*- coding: utf-8 -*-
import scrapy
from douban.items import TagItem,LinkItem
import re
from scrapy_redis.spiders import RedisSpider
import redis
from lxml import etree
from scrapy.utils.project import get_project_settings

class BookinfoSpider(scrapy.Spider):
    name = 'bookinfo'
    allowed_domains = ['book.douban.com']
    start_urls = ['https://book.douban.com/tag/?view=type&icn=index-sorttags-all']
    def __init__(self, *args, **kwargs):
        self.settings = get_project_settings()
        self.r_host = self.settings.get("REDIS_HOST")
        self.r_port = self.settings.get("REDIS_PORT")
        self.r_tag = self.settings.get("REDIS_TAG")
        self.r_book_url = self.settings.get("REDIS_BOOK_URL")
        self.rdb = redis.Redis(host=self.r_host,port=self.r_port, decode_responses=True)
        

    '''
    1、得到 tag -> 存入redis
    2、得到 redis -> tag -> 拼接tag_url -> 得到分类的页面 -> 控制得到
                    获取 book_url -> 存入redis
    '''
    def parse(self, response):
        pattern = r'<td><a href="(.*?)">.*?</a><b>.*?</b></td>'
        tags = re.findall(pattern,response.text)
        domain = "https://book.douban.com"
        
        # 如果没有tags,就存进Redis
        if self.r_tag not in self.rdb.keys():
            for tag in tags:
                self.rdb.lpush(self.r_tag, tag.encode())
        #for tag in tags:
        bookurl = domain + tags[0]
        # 请求得到每个tag的页面
        next_url = bookurl # 这个是进入tag
        if next_url:
            self.start_url = response.urljoin(next_url)
            yield scrapy.Request(url=self.start_url, callback=self.get_tag) # tag的列表页

    def get_tag(self,response):
        '''得到 当前tag 的所有页面'''
        parser = etree.HTML(response.text)
        page_range = parser.xpath("//div[@class='paginator']/a/text()")
        if page_range != []:
            page_max = page_range.pop() # page_max 总共有多少页
            print(page_range)
            for i in range(int(page_max)): 
                # 得到当前 page的 url_list
                next_url = self.start_url + "?start=%d&type=T" % (i*20)
                self.page_url = response.urljoin(next_url)
                yield scrapy.Request(url=self.page_url, callback=self.get_url) # 获取当前页面的 book url
    
    def get_url(self, response):
        '''得到 当前页面 的所有 book url'''
        parser = etree.HTML(response.text)
        li_list = parser.xpath("//li[@class='subject-item']")
        if li_list != None:
            for li in li_list:
                book_url = li.xpath("./div/a/@href")[0]
                self.rdb.lpush(self.r_book_url, book_url.encode()) # 把连接存到数据库里