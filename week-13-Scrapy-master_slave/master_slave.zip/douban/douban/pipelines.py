# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import redis,pymysql
from scrapy.exceptions import DropItem
from douban.items import TagItem,LinkItem

class TagPipeline(object):
    def __init__(self, r_host, r_port,r_list):
        self.r_host = r_host
        self.r_port = r_port
        self.r_list = r_list
    
    # 依赖注入
    @classmethod
    def from_crawler(cls,crawler):
        # 实例化当前类对象
        return cls(
            r_host = crawler.settings.get("REDIS_HOST"),
            r_port = crawler.settings.get("REDIS_PORT"),
            r_list = crawler.settings.get("REDIS_TAG")
        )


    # 连接数据库
    def open_spider(self, spider):
        # host是redis主机，需要redis服务端和客户端都启动 redis默认端口是6379
        self.r_db = redis.Redis(host=self.r_host, port=self.r_port, decode_responses=True)

    def process_item(self, item, spider):
        # 以链表的形式往 Redis数据库中放tag的list
        if isinstance(item,TagItem):
            self.r_db.lpush(self.r_list,item['tagname'].encode())
            return item
        
    # 关闭数据库
    def close_spider(self, spider):
        pass



class LinkPipeline(object):
    def __init__(self, r_host, r_port,r_list):
        self.r_host = r_host
        self.r_port = r_port
        self.r_list = r_list
    
    # 依赖注入
    @classmethod
    def from_crawler(cls,crawler):
        # 实例化当前类对象
        return cls(
            r_host = crawler.settings.get("REDIS_HOST"),
            r_port = crawler.settings.get("REDIS_PORT"),
            r_list = crawler.settings.get("REDIS_LINK")
        )


    # 连接数据库
    def open_spider(self, spider):
        # host是redis主机，需要redis服务端和客户端都启动 redis默认端口是6379
        self.r_db = redis.Redis(host=self.r_host, port=self.r_port, decode_responses=True)

    def process_item(self, item, spider):
        # 以链表的形式往 Redis数据库中放tag的list
        if isinstance(item,LinkItem):
            self.r_db.lpush(self.r_list,item['booklink'].encode())
            return item
    
    # 关闭数据库
    def close_spider(self, spider):
        pass



class DoubanPipeline(object):
    def process_item(self, item, spider):
        return item
