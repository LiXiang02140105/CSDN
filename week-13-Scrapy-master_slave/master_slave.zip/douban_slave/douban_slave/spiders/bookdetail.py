# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
import redis
from douban_slave.items import BookItem
import re

class BookdetailSpider(RedisSpider):
    name = 'bookdetail'
    #allowed_domains = ['book.douban.com']
    #start_urls = ['http://book.douban.com/']
    redis_key = 'myspider:start_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(BookdetailSpider, self).__init__(*args, **kwargs)
        self.r_db = redis.Redis(host="localhost", port=6379, decode_responses=True)
       
    def parse(self, response):
        print("======================",response.status)
        try:
            item = BookItem()
            vo = response.css("#wrapper") # id
            item['id'] = vo.re_first('div id="collect_form_([0-9]+)"></div>') #ID号
            item['title'] = vo.css("h1 span::text").extract_first() #书名
            print(item['title'])
            #使用正则获取里面的info里面的图书信息
            info = vo.css("#info").extract_first()
            authors = re.search('<span.*?作者.*?</span>(.*?)<br>',info,re.S).group(1) # 使 . 匹配包括换行在内的所有字符
            item['author'] = "、".join(re.findall('<a.*?>(.*?)</a>',authors,re.S)).replace("\n",'') #作者
            print(item['author'])
            item['press'] = " ".join(re.findall('<span.*?出版社:</span>\s*(.*?)<br>',info)) #出版社 # 任意空白字符
            print(item['press'])
            item['original'] = " ".join(re.findall('<span.*?原作名:</span>\s*(.*?)<br>',info)) #原作名
            print(item['original'])
            yz = re.search('<span.*?译者.*?</span>(.*?)<br>',info,re.S)
            if yz:
                item['translator'] = "、".join(re.findall('<a.*?>(.*?)</a>',yz.group(1),re.S)) #译者
            else:
                item['translator'] = ""
            print(item['translator'])
            item['imprint'] = re.search('<span.*?出版年:</span>\s*(.*?)<br>',info).group(1) #出版年
            print(item['imprint'])
            item['pages'] = re.search('<span.*?页数:</span>\s*([0-9]+)<br>',info).group(1) #页数
            print(item['pages'])
            item['price'] = re.search('<span.*?定价:</span>\s*(.*?)<br>',info).group(1) #定价
            print(item['price'])
            item['binding'] = " ".join(re.findall('<span.*?装帧:</span>\s*(.*?)<br>',info,re.S)) #装帧
            print(item['binding'])
            item['series'] = " ".join(re.findall('<span.*?丛书:</span>.*?<a .*?>(.*?)</a><br>',info,re.S)) #丛书
            print(item['series'])
            item['isbn'] = re.search('<span.*?ISBN:</span>\s*([0-9]+)<br>',info).group(1) #ISBN
            print(item['isbn'])
            item['score'] = vo.css("strong.rating_num::text").extract_first().strip() #评分
            print(item['score'])
            item['number'] = vo.css("a.rating_people span::text").extract_first() #评论人数
            print(item['number'])
            #print(item)
            yield item
        except:
            #此处将解析出现错误的url地址重新写回redis中去（其他key中）
            print("错误")
            self.r_db.lpush('bookspider:wrong_urls', response.url)
