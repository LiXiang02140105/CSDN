# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo

class DoubanSlavePipeline(object):
    def process_item(self, item, spider):
        print("*"*70)
        self.client = pymongo.MongoClient(host="localhost",port=27017)
        self.m_db = self.client.demo
        self.collection = self.m_db.douban
        
    
        id = item['id']      #ID号
        title = item['title'].strip()  #书名
        author = item['author'].strip().replace(" ",'')  #作者
        press = item['press']   #出版社
        original = item['original']  #原作名
        translator = item['translator'] #译者
        imprint = item['imprint']  #出版年
        pages = item['pages']    #页数
        price = item['price']    #定价
        binding = item['binding']  #装帧
        series = item['series']   #丛书
        isbn = item['isbn']     #ISBN
        score = item['score']    #评分
        number = item['number']   #评论人数
        
        document = {
            'id' : id,      #ID号
            'title' : title,  #书名
            'author' : author,  #作者
            'press' : press,   #出版社
            'original' : original, #原作名
            'translator' : translator, #译者
            'imprint' : imprint,  #出版年
            'pages' : pages,    #页数
            'price' : price,    #定价
            'binding' : binding,  #装帧
            'series' : series,   #丛书
            'isbn' : isbn,    #ISBN
            'score' : score,    #评分
            'number' : number,   #评论人数`
        }
        
        book = self.collection.insert_one(document).inserted_id
        return item
