'''商品类别管理视图文件
    1、基础的增删改查
'''

from django.http import HttpResponse
from django.shortcuts import render,redirect,reverse
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator
from common.models import Types

def index(request, pIndex='1'):
    '''浏览商品类别信息'''
    typeslist = Types.objects.extra(select={'_order':'concat(path,id)'}).order_by('_order')
    print(typeslist)
    if typeslist == []:
        context = {"info" : "当前系统没有维护的商品类别!"}
        return render(request, "myadmin/info.html", context)
    else:
        for ob in typeslist:
            ob.pname =' . .'*(ob.path.count(',')-1)
        page = Paginator(typeslist, 15)
        pIndex = int(pIndex)
        context = {}
        maxpages = page.num_pages # 最大页数
        print(type(maxpages))
        # 判断是否越界 
        if pIndex > maxpages:
            pIndex = maxpages
        if pIndex < 1:
            pIndex = 1
        
        context = {
            'pIndex' : pIndex, # 本页的数据
            'typeslist' : page.page(pIndex), # 本页的用户
            'prange' : page.page_range, # 全部的页数

        }
        return render(request, "myadmin/types/index.html", context)


'''添加商品类别信息'''
def add(request, pid=0):
    # 获取父类别信息，若没有则默认为根类别信息
    pid = int(pid)
    if pid == 0:
        context = {'pid':0,'path':'0,','name':'根类别'}
    else:
        ob = Types.objects.get(id=pid)
        context = {'pid':ob.id,'path':ob.path+str(ob.id)+',','name':ob.name}
    return render(request,'myadmin/types/add.html',context)

def insert(request):
    '''执行添加 商品类别'''
    type = Types()
    type.name = request.POST['name'] # 商品类别
    type.pid = request.POST['pid'] # 父类别
    type.path = request.POST['path'] # 路径
    try:
        type.save()
        context = {"info" : "添加 商品类别 成功!"}
    except Exception as error:
        print(error)
        context = {"info" : "添加 商品类别 失败!"}
    return render(request, "myadmin/info.html", context)

'''编辑 商品类别 信息'''
def edit(request, tid):
    '''加载编辑 商品类别 表单'''
    tid = int(tid)
    ob = Types.objects.get(id = tid)
    if ob == None:
        context = {"info" : "系统中无该 商品类别 信息"}
        return render(request, "myadmin/info.html", context)
    else:
        context = {"type" : ob}
        return render(request, "myadmin/types/edit.html", context)

def update(request, tid):
    '''执行更新 商品类别 名称'''
    tid = int(tid)
    ob = Types.objects.get(id = tid)
    ob.name = request.POST['name']
    try:
        ob.save()
        context = {"info" : "商品类别 信息更新成功!"}
    except Exception as error:
        print("商品类别 信息更新失败!",'\nerror:',error)
        context = {"info" : "商品类别 信息更新失败!"}
    return render(request, "myadmin/info.html", context)

def delete(request, tid):
    '''删除 商品类别 信息'''
    tid = int(tid)
    if Types.objects.get(pid=tid):
        context = {"info:" "不可删除, 该商品类别下还有子类别!"}
        return render(request, "myadmin/info.html", context)
    ob = Types.objects.get(id=tid)
    name = ob.name
    try:
        ob.delete()
        context = {"info" : "删除 商品类别 %s 成功!"%(name)}
    except Exception as error:
        print("删除 %s 商品类别 失败!"% (name),'\nerror:',error)
        context = {"info" : "删除 %s 商品类别 失败!"% (name)}
    return render(request, "myadmin/info.html", context)

