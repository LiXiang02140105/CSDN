from django.shortcuts import render,redirect
from django.http import HttpResponse
# 分页显示
from django.core.paginator import Paginator
from django.core.urlresolvers import reverse
# 注册用户
from common.models import Users, Goods, Types
def loadinfo(request):
    '''公共信息加载'''
    context = {}
    lists = Types.objects.filter(pid=0)
    context['typelist'] = lists
    return context
#'''网站的各种商品的展示''''
# Create your views here.
def index(request):
    '''项目前台首页'''
    # 获得页面右上角的 typelist
    context = loadinfo(request)
    return render(request,"web/index.html",context)


def lists(request, pIndex=1):
    '''项目前台列表页'''
    '''商品列表页(搜索&分页)'''
    # 获取 根 列表
    context = loadinfo(request)
    types = context['typelist']
    #获取商品信息查询对象
    mod = Goods.objects
    mywhere=[] #定义一个用于存放搜索条件列表

    #判断添加搜索条件，通过商品的标签，获得最后需要传输的商品列表
    # 商品分类
    tid = int(request.GET.get('tid',0))
    if tid > 0:
        # 查询所有包含 tid的子类
        print('tid:',tid)
        list = []
        for type in Types.objects.all():
            path = type.path.split(',')
            print('path:',path)
            if str(tid) in path:
                list.append(type.id)
        #list = mod.filter(typeid__in=Types.objects.only('id').filter(path__in=tid))
        list = mod.filter(typeid__in=list)
        mywhere.append("tid="+str(tid))
        print('goodlist！0:',list)
    else:
        list = mod.filter()
    print('list-0:',list)
    #获取、判断并封装关keyword键搜索
    kw = request.GET.get("keyword",None)
    if kw:
        # 查询商品名中只要含有关键字的都可以
        list = list.filter(goods__contains=kw)
        mywhere.append("keyword="+kw)

    #执行分页处理
    pIndex = int(pIndex)
    page = Paginator(list,5) #以5条每页创建分页对象
    maxpages = page.num_pages #最大页数
    #判断页数是否越界
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    goodslist = page.page(pIndex) #当前页数据
    plist = page.page_range   #页码数列表

    #封装信息加载模板输出
    context['goodslist'] = goodslist # 商品列表
    context['plist'] = plist # 页数范围，用于底部分页计算
    context['pIndex'] = pIndex 
    context['maxpages'] = maxpages
    context['mywhere'] = mywhere
    context['tid'] = int(tid) # 商品分类标签
    return render(request,"web/list.html",context)

def detail(request, gid=1):
    '''商品详情页'''
    context = loadinfo(request)
    #加载商品详情信息
    ob = Goods.objects.get(id=gid)
    ob.clicknum += 1 # 点击量加1
    ob.save()
    context['goods'] = ob
    return render(request,"web/detail.html",context)



