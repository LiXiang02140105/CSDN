from django.shortcuts import render,redirect
from django.http import HttpResponse

from django.core.urlresolvers import reverse
# 注册用户
from common.models import Users

'''# ==============前台会员登录注册操作===================='''
def login(request):
    '''登陆界面'''
    return render(request, "web/login.html")

def dologin(request):
    '''执行登陆操作'''
    # 校验验证码
    verifycode = request.session['verifycode']
    code = request.POST['verifycode']
    if code != verifycode:
        context = {"info": "验证码错误!"}
        return render(request, "web/login.html", context)

    #根据账号获取登录者信息
    username = request.POST['username']
    user = Users.objects.get(username=username)
    #判断当前用户是否是会员用户
    if user.state != 2:
        # 验证密码
        import hashlib
        md5 = hashlib.md5() 
        md5.update(bytes(request.POST['password'],encoding= "utf8"))
        if user.password == md5.hexdigest():
            # 此处登录成功，将当前登录信息放入到session中，并跳转页面
            request.session['vipuser'] = user.toDict()
            #print(json.dumps(user))
            return redirect(reverse('index'))
        else:
            context = {'info':'登录密码错误！'}
    else:
        context = {'info':'此账号为 禁用会员 账号！'}

    return render(request,"web/login.html",context)

def logout(request):
    '''执行退出操作'''
     # 清除登录的session信息
    del request.session['vipuser']
    # 跳转登录页面（url地址改变）
    return redirect(reverse('login'))
    # 加载登录页面(url地址不变)


import random
from PIL import Image, ImageDraw, ImageFont
def verify(request):
    # tt9830z_.ttf
    # 定义变量，用于画面的背景色、宽、高
    bgcolor  = (255, 255 ,255)
    width = 100
    height = 25
    # 创建画面对象
    image = Image.new('RGB', (width, height), bgcolor)
    # 创建画笔对象
    draw = ImageDraw.Draw(image)
    # 调用画笔对象的 point 绘制噪点
    for i in range(0, 100):
        xy = (random.randrange(0,width), random.randrange(0, height))
        fill = (random.randrange(0,255), 255, random.randrange(0,255))
        draw.point(xy, fill=fill)
    
    # 定义验证码的备选值
    str1 = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890'
    # 随机选取4个数
    rand_str = ''
    for i in range(0, 4):
        rand_str += str1[random.randrange(0, len(str1))]
    
    # 构造字体对象
    font = ImageFont.truetype("static/georgiaz.ttf",21)
    # 构造字体颜色
    fontcolor = (255, random.randrange(0,255),random.randrange(0,255))
    draw.text((5,random.randrange(-2,2)),rand_str[0], font=font, fill=(255, random.randrange(0,255),random.randrange(0,255)))
    draw.text((25,random.randrange(-2,2)),rand_str[1], font=font, fill=(random.randrange(0,255), 255,random.randrange(0,255)))
    draw.text((50,random.randrange(-2,2)),rand_str[2], font=font, fill=(random.randrange(0,255), random.randrange(0,255),255))
    draw.text((75,random.randrange(-2,2)),rand_str[3], font=font, fill=( random.randrange(0,255), random.randrange(0,255),random.randrange(0,255)))
    # 释放画笔
    del draw

    # 存入session中，为下一步验证
    request.session['webverifycode'] = rand_str
    request.session['verifycode'] = rand_str

    # 内存文件操作
    import io
    buffer = io.BytesIO()
    # 将图片保存在内存中，文件类型为png
    image.save(buffer, 'png')
    return HttpResponse(buffer.getvalue(), 'image/png')
   
def register(request):
    '''加载注册表单'''
    
    return render(request, "web/register.html")

def doregister(request):
    '''执行注册'''
    # 校验验证码
    verifycode = request.session['webverifycode']
    code = request.POST['verifycode']
    print(code)
    if code != verifycode:
        context = {"info": "验证码错误!"}
        print(context)
        return render(request, "web/login.html", context)
    user = Users()
    user.name = request.POST['username']
    user.phone = request.POST['phone']
    import hashlib
    user.password = hashlib.md5(bytes(request.POST['password'],encoding='utf8')).hexdigest()
    try:
        user.save()
        request.session['vipuser'] = user.toDict() # 以字典格式，将用户存储到 session 中
        return render(request, "web/index.html")
    except Exception as error:
        print(error)
        context = {"info" : "注册失败!"}
        return render(request, "web/register.html", context) 
    
def verifyusername(request):
    # 获取快速注册用户的 账号、手机号、密码、真实姓名 
    username = request.POST['username']
    isExistUser = Users.objects.filter(username=username)
    if isExistUser:
        #  不能注册
        return HttpResponse(0)
    else:
        return HttpResponse(1)