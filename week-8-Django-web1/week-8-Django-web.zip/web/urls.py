from django.contrib import admin
from django.conf.urls import url
from web.views import index, users  



urlpatterns = [
    url(r'^$', index.index, name='index'),
    # 商品列表
    url(r'^list$', index.lists, name='list'),
    url(r'^list/pIndex=(?P<pIndex>[0-9]+)$', index.lists, name='list'),
    # 商品详情
    url(r'^detail/gid=(?P<gid>[0-9]+)$', index.detail, name='detail'),

    # 用户登录与注册
    # 登录
    url(r'^login$', users.login, name='login'),
    # 执行登陆
    url(r'^dologin$', users.dologin, name='dologin'),
    # 退出登录
    url(r'^logout$', users.logout, name='logout'),
    # 用户注册表单
    url(r'^register$', users.register, name='register'),
    # 执行用户注册
    url(r'^doregister$', users.doregister, name='doregister'),
    # 前台验证码
    url(r'^verify$', users.verify, name='verify'),
    # 前台验证 用户名是否注册
    url(r'^verifyusername', users.verifyusername, name="verifyusername"),
]
