"""myobject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url, include

''' 后台开发
20190619 09:00-10:00 60min ：基础框架
20190620 08:40-10:00 80min ：会员框架搭建
20190621 08:50-10:00 70min : 会员信息操作
20190622 09:30-12:00 150min
         15:30-18:00 150min:
    1、中间件：shopmiddleware
        添加中间件、执行登陆与退出（session）、添加验证码
20190623 11:00-12:00 60min :
    2、商品类别、商品信息添加
20190624 09:00-10:00 60min :
    3、重置会员密码、
20190625 00:00-00:30 30min : 
    为商品类别添加删除判断、为会员信息浏览添加搜索&分页效果、
 20190625 09:00-10:30 60min : 重置会员密码，前端JS调整
'''

''' 前台开发
20190626 09:30-10:00 30min : 后台商品增删界面
20190627 09:00-10:00 60min ：后台商品搜索查询界面
20190701 09:30-10:00 30min : 登录界面
前台商品列表页
前台商品详情页

'''


urlpatterns = [
    # url(r'admin/', admin.site.urls),
    # 后台目录
    url(r'^myadmin/',include('myadmin.urls')),
    # 前台目录
    url(r'^', include('web.urls')),

]
