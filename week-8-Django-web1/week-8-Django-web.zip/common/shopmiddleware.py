from django.shortcuts import redirect
from django.core.urlresolvers import reverse
import re


'''中间件'''
class ShopMiddleware(object):
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.
        print("shopmiddleware init……")

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        """每次页面切换的时候都会调用"""
        '''1、定义往后在哪后台不用登陆也可访问的路由url'''
        urllist = ['/myadmin/login','/myadmin/dologin','/myadmin/logout', '/myadmin/verify']
        '''2、获取当前请求的路径'''
        path = request.path
        '''3、判断是否是访问后台的请求，且是否可以不用登陆就能访问'''
        if re.match('/myadmin',path) and (path not in urllist):
            if 'adminuser' not in request.session:
                print("no adminuser in session")
                """如果没有登陆，即 session里没有adminuesr的key，就需要登录"""
                return redirect(reverse("myadmin_login"))
              
        response = self.get_response(request)
        print("shopmiddleware call……")

        # Code to be executed for each request/response after
        # the view is called.

        return response