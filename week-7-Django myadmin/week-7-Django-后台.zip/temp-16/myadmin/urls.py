from django.conf.urls import url
from myadmin.views import index, users, types, goods
'''
重置会员密码、为会员信息浏览添加搜索&分页效果、为商品类别添加删除判断
'''
urlpatterns = [
    # 后台主页
    url(r'^$', index.index, name="myadmin_index"),
    #'''0、后台登陆路由'''
    url(r'^login$', index.login, name="myadmin_login"),
    url(r'^dologin$', index.dologin, name="myadmin_dologin"),
    url(r'^logout$', index.logout, name="myadmin_logout"),
    url(r'^verify$', index.verify, name="myadmin_verify"),
    url(r'^reset$', index.reset, name="myadmin_reset"), # 登陆中未实现
    url(r'^doreset$', index.doreset, name="myadmin_doreset"), # 登陆中未实现

    #''' 1、会员管理 '''
    # 浏览会员
    url(r'^users/pIndex=(?P<pIndex>[0-9]+)$', users.index, name="myadmin_users_index"),
    # 2、新增会员
    url(r'^users/add$', users.add, name="myadmin_users_add"),
    url(r'^users/insert$', users.insert, name="myadmin_users_insert"),
    # 3、编辑会员
    url(r'^users/edit/uid=(?P<uid>[0-9]+)$', users.edit, name="myadmin_users_edit"),
    url(r'^users/update/uid=(?P<uid>[0-9]+)$', users.update, name="myadmin_users_update"),
    # 4、删除会员
    url(r'^users/delete/uid=(?P<uid>[0-9]+)$', users.delete, name="myadmin_users_delete"),
    # 5、管理员重置密码
    url(r'^users/reset/uid=(?P<uid>[0-9]+)$', users.reset, name="myadmin_users_reset"), 
    url(r'^users/doreset$', users.doreset, name="myadmin_users_doreset"),

    #''' 2、商品类别管理 '''
    # 浏览商品类别
    url(r'^types/pIndex=(?P<pIndex>[0-9]+)$', types.index, name="myadmin_types_index"),
    # 2、新增商品类别
    url(r'^types/add/pid=(?P<pid>[0-9]+)$', types.add, name="myadmin_types_add"),
    url(r'^types/insert$', types.insert, name="myadmin_types_insert"),
    # 3、编辑商品类别
    url(r'^types/edit/uid=(?P<tid>[0-9]+)$', types.edit, name="myadmin_types_edit"),
    url(r'^types/update/uid=(?P<tid>[0-9]+)$', types.update, name="myadmin_types_update"),
    # 4、删除商品类别
    url(r'^types/delete/uid=(?P<tid>[0-9]+)$', types.delete, name="myadmin_types_delete"),

     # 后台商品信息管理
    url(r'^goods/pIndex=(?P<pIndex>[0-9]+)$', goods.index, name="myadmin_goods_index"),
    url(r'^goods/add$', goods.add, name="myadmin_goods_add"),
    url(r'^goods/insert$', goods.insert, name="myadmin_goods_insert"),
    url(r'^goods/del/(?P<gid>[0-9]+)$', goods.delete, name="myadmin_goods_del"),
    url(r'^goods/edit/(?P<gid>[0-9]+)$', goods.edit, name="myadmin_goods_edit"),
    url(r'^goods/update/(?P<gid>[0-9]+)$', goods.update, name="myadmin_goods_update"),

]
