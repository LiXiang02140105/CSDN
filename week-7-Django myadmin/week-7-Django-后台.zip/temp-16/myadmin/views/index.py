from django.shortcuts import render,redirect
from django.http import HttpResponse
from common.models import Users
from django.core.urlresolvers import reverse
# Create your views here.
def index(request):
    return render(request,"myadmin/index.html")

'''# ==============后台管理员操作===================='''
def login(request):
    '''登陆界面'''
    return render(request, "myadmin/login.html")

def dologin(request):
    '''执行登陆操作'''
    # 校验验证码
    verifycode = request.session['verifycode']
    code = request.POST['verifycode']
    if code != verifycode:
        context = {"info": "验证码错误!"}
        return render(request, "myadmin/login.html", context)


    #根据账号获取登录者信息
    user = Users.objects.get(username=request.POST['username'])
    #判断当前用户是否是后台管理员用户
    if user.state == 0:
        # 验证密码
        import hashlib
        md5 = hashlib.md5() 
        md5.update(bytes(request.POST['password'],encoding="utf8"))
        if user.password == md5.hexdigest():
            # 此处登录成功，将当前登录信息放入到session中，并跳转页面
            request.session['adminuser'] = user.toDict()
            #print(json.dumps(user))
            return redirect(reverse('myadmin_index'))
        else:
            context = {'info':'登录密码错误！'}
    else:
        context = {'info':'此用户非后台管理用户！'}

    return render(request,"myadmin/login.html",context)

def logout(request):
    '''执行退出操作'''
     # 清除登录的session信息
    del request.session['adminuser']
    # 跳转登录页面（url地址改变）
    return redirect(reverse('myadmin_login'))
    # 加载登录页面(url地址不变)


import random
from PIL import Image, ImageDraw, ImageFont
def verify(request):
    # tt9830z_.ttf
    # 定义变量，用于画面的背景色、宽、高
    bgcolor  = (255, 255 ,255)
    width = 100
    height = 25
    # 创建画面对象
    image = Image.new('RGB', (width, height), bgcolor)
    # 创建画笔对象
    draw = ImageDraw.Draw(image)
    # 调用画笔对象的 point 绘制噪点
    for i in range(0, 100):
        xy = (random.randrange(0,width), random.randrange(0, height))
        fill = (random.randrange(0,255), 255, random.randrange(0,255))
        draw.point(xy, fill=fill)
    
    # 定义验证码的备选值
    str1 = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890'
    # 随机选取4个数
    rand_str = ''
    for i in range(0, 4):
        rand_str += str1[random.randrange(0, len(str1))]
    
    # 构造字体对象
    font = ImageFont.truetype("static/georgiaz.ttf",21)
    # 构造字体颜色
    fontcolor = (255, random.randrange(0,255),random.randrange(0,255))
    draw.text((5,random.randrange(-2,2)),rand_str[0], font=font, fill=(255, random.randrange(0,255),random.randrange(0,255)))
    draw.text((25,random.randrange(-2,2)),rand_str[1], font=font, fill=(random.randrange(0,255), 255,random.randrange(0,255)))
    draw.text((50,random.randrange(-2,2)),rand_str[2], font=font, fill=(random.randrange(0,255), random.randrange(0,255),255))
    draw.text((75,random.randrange(-2,2)),rand_str[3], font=font, fill=( random.randrange(0,255), random.randrange(0,255),random.randrange(0,255)))
    # 释放画笔
    del draw

    # 存入session中，为下一步验证
    request.session['verifycode'] = rand_str

    # 内存文件操作
    import io
    buffer = io.BytesIO()
    # 将图片保存在内存中，文件类型为png
    image.save(buffer, 'png')
    return HttpResponse(buffer.getvalue(), 'image/png')
   
def reset(request):
    username = request.POST['username']
    ob = Users.objects.get(username=username)
    if ob == None:
        context = {"info" : "系统中不存在该账号会员!"}
        return render(request, "myadmin/login.html", context)
    context = {
        "username" : username,
        "name" : ob.name
    }
    return render(request, "myadmin/reset.html", context)


def doreset(request):
    ob = Users.objects.POST(username=username)
    import hashlib
    md5 = hashlib.md5()
    md5.update(bytes(request.POST['password'], encoding="utf8"))
    ob.password = md5.hexdigest()
    try:
        ob.save()
        context = {"info" : "会员密码修改成功!请使用新密码登陆!"}
        return render(request, "myadmin/login.html", context)
    except:
        context = {"info" : "会员密码修改失败!请重新修改!"}
        return render(request, "myadmin/reset.html", context)