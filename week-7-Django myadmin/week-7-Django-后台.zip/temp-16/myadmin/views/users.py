'''会员管理视图文件
    1、基础的增删改查
    2、login + reset password
'''

from django.http import HttpResponse
from django.shortcuts import render,redirect,reverse
from django.views.decorators.csrf import csrf_exempt
# 分页显示
from django.core.paginator import Paginator
from common.models import Users
from datetime import datetime
# 搜索
from django.db.models import Q

def index(request, pIndex='1'):
    '''浏览用户信息'''
    list = Users.objects.all()
    if list == None:
        context = {"info" : "当前系统没有维护的用户!"}
        return render(request, "myadmin/info.html", context)
    else:
        #获取商品信息查询对象
        mod = Users.objects
        mywhere=[] #定义一个用于存放搜索条件列表

        # 获取、判断并封装关keyword键搜索
        kw = request.GET.get("keyword", None)
        print('keyword:',kw,type(kw))
        if kw:
            # 查询用户中只要含有关键字的都可以
            list = mod.filter(name__contains=kw)
            mywhere.append("keyword="+kw)
        else:
            list = mod.filter()
        # 获取、判断并封装用户性别 sexid 搜索条件
        sexid = request.GET.get('sexid', '')
        print('sexid:',sexid,type(sexid))
        if sexid != '':
            # tids = Users.objects.filter(Q(id=typeid) | Q(pid=typeid)).values_list('id',flat=True)
            # 使用 Q 构造过滤类，value_list获取某个字段，flat是合并过滤结果为一个 list
            # sexid = int(sexid)
            mywhere.append("sexid=")
            print('filter sexid:',sexid,type(sexid))
            list = list.filter(sex=int(sexid))
            print(list)
            mywhere.append(sexid)
        # 获取、判断并封装 用户 state搜索条件
        state = request.GET.get('state','')
        print('state:',state,type(state))
        if state != '':
            # state = int(state)
            mywhere.append("state=")
            print('filter state:',state,type(state))
            list = list.filter(state=int(state))
            print(list)
            mywhere.append(state)
        userspage = Paginator(list, 5)
        pIndex = int(pIndex)
        context = {}
        maxpages = userspage.num_pages # 最大页数
        # 判断是否越界 
        if pIndex > maxpages:
            pIndex = maxpages
        if pIndex < 1:
            pIndex = 1
        
        context = {
            'pIndex' : pIndex, # 本页的数据
            'users' : userspage.page(pIndex), # 本页的用户
            'prange' : userspage.page_range, # 全部的页数
            'mywhere':mywhere # 关键词
        }
        return render(request, "myadmin/users/index.html", context)


'''添加会员信息'''
def add(request):
    '''加载添加会员表单'''
    return render(request, "myadmin/users/add.html")

def insert(request):
    '''执行添加'''
    user = Users()
    
    user.username = request.POST['username'] # 账号
    user.name = request.POST['name'] # 姓名
    user.sex = request.POST['sex'] # 性别
    user.address = request.POST['address'] # 地址
    user.code = request.POST['code'] # 邮编
    user.email = request.POST['email'] # 邮箱
    user.phone = request.POST['phone'] # 电话
    user.state = 1
    user.addtime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 获取密码，使用 md5 加密
    import hashlib
    md5 = hashlib.md5()
    md5.update(bytes(request.POST['password'], encoding="utf8"))

    user.password = md5.hexdigest()

    try:
        user.save()
        context = {"info" : "添加会员成功!"}
    except Exception as error:
        print(error)
        context = {"info" : "添加会员失败!"}
    return render(request, "myadmin/info.html", context)

'''编辑会员信息'''
def edit(request, uid):
    '''加载编辑会员信息表单'''
    uid = int(uid)
    ob = Users.objects.get(id = uid)
    if ob == None:
        context = {"info" : "系统中无该用户信息"}
        return render(request, "myadmin/info.html", context)
    else:
        context = {"user" : ob}
        return render(request, "myadmin/users/edit.html", context)

def update(request, uid):
    '''执行更新'''
    uid = int(uid)
    ob = Users.objects.get(id = uid)
    ob.name = request.POST['name']
    ob.sex = request.POST['sex']
    ob.address = request.POST['address']
    ob.code = request.POST['code']
    ob.phone = request.POST['phone']
    ob.email = request.POST['email']
    ob.state = request.POST['state']
    try:
        ob.save()
        context = {"info" : "会员信息更新成功!"}
    except Exception as error:
        print("会员信息更新失败!",'\nerror:',error)
        context = {"info" : "会员信息更新失败!"}
    return render(request, "myadmin/info.html", context)

def delete(request, uid):
    '''删除会员信息'''
    uid = int(uid)
    ob = Users.objects.get(id=uid)
    try:
        ob.delete()
        context = {"info" : "删除 %d 会员成功!"%(uid)}
    except Exception as error:
        print("删除 %d 会员失败!"% (uid),'\nerror:',error)
        context = {"info" : "删除 %d 会员失败!"% (uid)}
    return render(request, "myadmin/info.html", context)

def reset(request,uid):
    uid = int(uid)
    ob = Users.objects.get(id=uid)
    if ob == None:
        context = {"info" : "系统中不存在该账号会员!"}
        return render(request, "myadmin/login.html", context)
    context = {
        "username" : ob.username,
        "name" : ob.name
    }
    return render(request, "myadmin/users/reset.html", context)


def doreset(request):
    username = request.POST['username']
    ob = Users.objects.get(username=username)

    password = request.POST['password']
    repassword = request.POST['repassword']
    if password != repassword:
        context = {
            "username" : ob.username,
            "name" : ob.name,
            "info" : "两次输入密码不一致!"
            }
        return render(request, "myadmin/users/reset.html", context)
    import hashlib
    md5 = hashlib.md5()
    md5.update(bytes(password, encoding="utf8"))
    ob.password = md5.hexdigest()
    try:
        ob.save()
        context = {"info" : "会员密码修改成功!请使用新密码登陆!"}
        return render(request, "myadmin/login.html", context)
    except:
        context = {"info" : "会员密码修改失败!请重新修改!"}
        return render(request, "myadmin/users/reset.html", context)